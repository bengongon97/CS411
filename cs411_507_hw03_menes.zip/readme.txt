I indicated all the answers in my output file.

Please run the attached python program and see the console for explanations.

Thank you.