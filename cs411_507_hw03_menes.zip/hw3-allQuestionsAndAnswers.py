import binascii
import random
import numpy
from numpy import polymul, polydiv, poly1d

# It clocks the LFSR once;
# Note that it changes LFSR state S
# S[0] is the leftmost bit of the LFSR
# The connection polynomial setting example:
# 1+x+x^3 --> C[0] = C[1} = C[3} = 1, C[2] = 0

# S is the initial state. (to eliminate confusion)
def LFSR(C, S):
    L = len(S)
    fb = 0
    out = S[L-1]
    for i in range(0,L):
        fb = fb^(S[i]&C[i+1])
    for i in range(L-1,0,-1):
        S[i] = S[i-1]

    S[0] = fb
    return out, S

# Finds the period of a binary sequence s, if it repeates itself
# Note that the number of bits in s must be twice the size of the period
def FindPeriod(s):
    n = len(s)
    for T in range(1,n+1):
        chck = 0
        for i in range(0,n-T-1):
            if (s[i] != s[i+T]):
                chck += 1
                break
        if chck == 0:
            break
    if T > n/2:
        return n
    else:
        return T

def PolPrune(P):
    n = len(P)
    i = n-1
    while (P[i] == 0):
        del P[i]
        i = i-1
    return i

def PolDeg(P):
    n = len(P)
    i = n-1
    while (P[i] == 0):
        i = i-1
    return i

# P gets Q
def PolCopy(Q, P):
    degP = len(P)
    degQ = len(Q)
    if degP >= degQ:
        for i in range(0,degQ):
            Q[i] = P[i]
        for i in range(degQ, degP):
            Q.append(P[i])
    else: # degP < deqQ
        for i in range(0,degP):
            Q[i] = P[i]
        for i in range(degP, degQ):
            Q[i] = 0
        PolPrune(Q)

# given the sequence s, it returns the length and the connection
# polynomial of the shortest LFSR that generates s
def BM(s):
    n = len(s)
    C = []
    B = []
    T = []
    L = 0
    m = -1
    i = 0
    C.append(1)
    B.append(1)

    while(i<n):
        delta = 0
        clen = len(C)
        for j in range(0, clen):
            delta ^= (C[j]*s[i-j])
        if delta == 1:
            dif = i-m
            PolCopy(T, C)
            nlen = len(B)+dif
            if(clen >= nlen):
                for j in range(dif,nlen):
                    C[j] = C[j] ^ B[j-dif]
            else: # increase the degree of C
                for j in range(clen, nlen):
                    C.append(0)
                for j in range(dif, nlen):
                    C[j] = C[j] ^ B[j-dif]
            PolPrune(C)
            if L <= i/2:
                L = i+1-L
                m = i
                PolCopy(B, T)
        i = i+1
    return L, C

# Takes a text and converts it to binary using ASCII encoding
def ASCII2bin(msg):
    M_i = []
    Mlen = len(msg)
    for i in range(0,Mlen):
        ascii_no = ord(msg[i])
        ascii_bin = bin(ascii_no)
        char_len = len(ascii_bin)
        if(char_len<9):
            for j in range(0,9-char_len):
                M_i.append(0)
        for j in range(2,char_len):
            M_i.append(int(ascii_bin[j]))
    return M_i

# Retransformation to see the decrypted message
def bin2ASCII(msg):
    res = list()
    for i in range(len(msg)//7):
        bins = msg[:7]
        str_bin = ''.join(str(x) for x in bins)
        res.append(chr(int(str_bin,2)))
        msg = msg[7:]
    return "".join(res)

if __name__ == '__main__':

#Q1
    print("Question 1:")

    connectionPolynomialOfQ1 = [1,1,0,0,0,0,1]
    initialState = [1,0,0,0,0,0]
    periodOfQ1 = FindPeriod(connectionPolynomialOfQ1)
    output_bit_array = []
    #LFSR(myC, myS)
    for i in range(0,periodOfQ1):
        lfsr_outputbit, initialState = LFSR(connectionPolynomialOfQ1, initialState)
        #LFSR(connectionPolynomialOfQ1, newInitialState)
        output_bit_array.append(lfsr_outputbit)
    print(output_bit_array)
    print("Period is", periodOfQ1)

    print("Since the degree of the polynomial is 6, period must've been 2^6-1. But it is apparently 7. So it is not primitive.")

#Q2
    print("")
    print("Question 2:")
    binary_sequence = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 1, 1]
    L,C = BM(binary_sequence)
    print("Length of the polynomial is", L)
    print("Connection polynomial is", C)


#Q3
    print("")
    print("Question 3:")
    sequence_given_in_question3 = [1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0]

    dearStudentInBinary = ASCII2bin("Dear Student") # Length is 84.
    firstLinesOfSequenceGiven = sequence_given_in_question3[0:84]

    toBeSentToBM = [0]*84 #again the same length

    for y in range(len(firstLinesOfSequenceGiven)):
        toBeSentToBM[y] = firstLinesOfSequenceGiven[y] ^ dearStudentInBinary[y]

    connection_polynomial_of_Q3 = BM(toBeSentToBM)[1]
    print(connection_polynomial_of_Q3)

    theBigStoBeSent = toBeSentToBM[0:11]
    theBigStoBeSent.reverse()
    keyArray = [1]*len(sequence_given_in_question3)

    for u in range(len(sequence_given_in_question3)):
        keyArray[u] = LFSR(connection_polynomial_of_Q3, theBigStoBeSent)[0]

    resultQ3 = [1]*len(sequence_given_in_question3)
    for o in range(len(sequence_given_in_question3)):
        resultQ3[o] = sequence_given_in_question3[o] ^ keyArray[o]

    print(bin2ASCII(resultQ3))


# Q4
    #a)
    print("")
    print("Question 4:")

    p1 = [1,1,0,1,0,1,0,0]
    p2 = [1,0,0,0,1,1,1,1]

    multiplication = polymul(p1, p2)

    p3 = [1,0,0,0,1,1,0,1,1]

    div, rem = polydiv(multiplication, p3)

    result = []
    for i in rem:
        result.append(i%2)

    print("Result of a) is:")
    print(poly1d(result))

    #b)
    print("b)")

    p4 = [1,1,0,1,0,1,0,0]
    p5 = [1,1,0,0,0,1,0,1]

    isEqualToOne = polymul(p4, p5)

    div2,rem2 = polydiv(isEqualToOne, p3)

    result2 = []
    for i in rem2:
        result2.append(i%2)

    if(result2 == [0,0,0,0,0,0,0,1]):
        print("Once we calculate the result, it is equal to 1. Then, it is proven that they are inverse of each other.")
    else:
        print("They are not inverse of each other.")
#Q5
    print("")
    print("Question 5:")

    print("In AES, if we remove the ShiftRow and MixColumn layers, then")
    print("one byte in plaintext will affect only the correspoding byte in the cipher text.")
    print("Thus, encrpytion will be composed of 16 substitution ciphers and the block size will be just 8.")
    print("Then, attacking became easier. We can separate them and attack it.")
    print("For chosen plaintext attack in specific,")
    print("We can choose all-the-same pairs like:")
    print("P0 = [0,0,0,...,0], P1 = [1,1,1,...,1], P255 = [255,255,255,...,255]")










