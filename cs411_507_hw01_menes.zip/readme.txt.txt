All the details are indicated in the word document. :)
M. Enes ��M�EK :)