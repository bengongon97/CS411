from string import ascii_lowercase
LETTERS = {index : letter for index, letter in enumerate(ascii_lowercase, start=0)}
LETTERS_REVERSE = {letter : index for index, letter in enumerate(ascii_lowercase, start=0)}
print(LETTERS)
print(LETTERS_REVERSE)


def deciphering(word: str, shiftAmount):
    # bar and one
    result = []
    length = word.__len__()
    wordGiven = list(word)
    t = 0
    while t < length:
        letter = wordGiven[t]
        index = LETTERS_REVERSE.get(letter)
        letter = getLetter(shiftAmount, index)
        wordGiven[t] = letter
        t = t+1

    word = "".join(wordGiven)
    result.append(word)

    return result


def getLetter(shiftAmount, currentIndex):
    if shiftAmount+currentIndex > 25:
        compensation = 26 - currentIndex
        shiftAmount = shiftAmount - compensation
        currentIndex = 0
        # move newShift amount from index 0
        newltr = LETTERS.get(shiftAmount)
    else:
        newltr = LETTERS.get(shiftAmount + currentIndex)
    return newltr


if __name__ == '__main__':
        shift = 0

        while shift < 26:
            takenResult = deciphering("dct", shift)
            print(takenResult, shift)
            shift = shift + 1
