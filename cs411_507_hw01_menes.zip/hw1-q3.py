


def vigenere_decipher (cipher_text, key):
    shift_array = []
    for k in key:
        index = ord(k) - ord('A')
        shift_array.append(index)

    i = 0
    plainText = []
    for letter in cipher_text:
        if letter.isalpha():
            index = ord(letter) - ord('A')
            shiftBy = i % shift_array.__len__()
            index = (index - shift_array[shiftBy]) % 26
            plainText.append(chr(ord('A')+index))
            i = i+1
        else:
            plainText.append(letter)
    print("".join(plainText))



if __name__ == '__main__':
    cipher_text = "WADYZMHL TQ PSWAR RTI GNXC FLWAR, MHIF NYB AZSE LEMMB, OFR QBDRNRURU QTDRIFRYR DIGHWRE."
    keyToGive = "ONLYME"
    vigenere_decipher(cipher_text, keyToGive)