from string import ascii_uppercase
LETTERS = {index : letter for index, letter in enumerate(ascii_uppercase, start=0)}
LETTERS_REVERSE = {letter : index for index, letter in enumerate(ascii_uppercase, start=0)}

def frequencyCounter(stream):
    res = {}
    for lett in stream:
        if lett.isalpha():
            if res.get(lett) is None:
                res[lett] = 1
            else:
                res[lett] = res[lett] + 1
    return res

def decipher_possibility(text, a ,b):
    plainText = []
    for letter in text:
        if letter.isalpha():
            c = ord(letter) - ord('A')
            #print(c)
            o = c-b
            if o > 0:
                while o % a is not 0:
                    o = o +26
            elif o < 0 :
                o = o + 26
                while o % a is not 0:
                    o = o +26


            wantedNumber = int(o/a) % 26
            myLetter = LETTERS.get(wantedNumber)
            plainText.append(myLetter)

        else:
            plainText.append(letter)

    print("".join(plainText))
    #print(plainText)

def decipher_the_cipher(cipherText):
    letterFrequency = frequencyCounter(cipherText)
    letterFrequency = sorted(letterFrequency.items(), key=lambda x: x[1])
    most_freq_letter = letterFrequency[letterFrequency.__len__()-1][0]
    #print(most_freq_letter + " is most freq letter")
    alphaPossiblities = [1,3,5,7,9,11,15,17,19,21,23,25]

    p = LETTERS_REVERSE.get(most_freq_letter)
    #print(p)

    for a in alphaPossiblities:
        b = p - a*4
        if(b < 0):
            b = b + 26
        decipher_possibility(cipherText, a, b)



if __name__ == '__main__':
    #The most frequent letter in the plaintext is E.
    cipher_stream = "QRG HFS PV SDG HFMX IDK MXIXFG. F HFS BFS QX MXVGKDJXM QRG SDG MXIXFGXM."
    decipher_the_cipher(cipher_stream)
