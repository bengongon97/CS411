import math
from sympy import mod_inverse

n = 876757185537497549441688380876

def calc(a, b):

    d =  math.gcd(a, n)
    #it is asked to find solution for x where ax is congruent to b modulus n
    if d == 1:
        x = (b * mod_inverse(a,n)) % n
        print("One and the only x is: ", x, "\n")
    elif math.gcd(d,b) is 1:
        print("There is no solution because d (i.e. gcd(a,n)) does not divide b")
    else:
        print("There are exactly", d, "solutions\n")
        x = (mod_inverse(a//d,n//d) * (b//d)) % (n//d)
        while d is not 0:
            print("One of them is:", x + ((d-1)*(n//d)), "\n")
            d = d - 1


if __name__ == '__main__':
    a1 = 726529482843138430251706107365
    b1 = 374479581720142608093094131318
    a2 = 682523910410036363063715440006
    b2 = 233807680780339430865969182340
    a3 = 217662435485891894157847112298
    b3 = 815512939769276810314824385915

    calc(a1, b1)
    calc(a2, b2)
    calc(a3, b3)