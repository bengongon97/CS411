from math import gcd

def generators(relative_primes, a):
    gens = []

    for i in relative_primes:
        series = []

        k = i
        for j in range(1, 57):

            # print (k)
            if k in relative_primes and k not in series:
                series.append(k)

            k = (k * i) % a
        if len(series) == len(relative_primes):
            gens.append(i)

    return gens

def quadraticRes(z):
    qResidue = []
    for number in z:
        xx = (number * number) % 58
        if xx not in qResidue:
            qResidue.append(xx)
    qResidue.sort()
    return qResidue


def answers():
    z = 1
    x = 1
    zElements = []

    while z < 58:
        if(gcd(z, 58) == 1):
            zElements.append(z)
        z = z + 2

    generatorsOfZ = generators(zElements, 58)

    print("a) There are", len(zElements) ,"elements.")
    print("They are:", zElements)

    print("b) There are", len(generatorsOfZ), "generators.", "They are:", generatorsOfZ)

    q58 = quadraticRes(zElements)

    print("c) There are", len(q58), "elements in Q58", "They are", q58)

    generatorsOfQ58 = generators(q58,58)

    print("d) There are", len(generatorsOfQ58), "generators.", "They are:", generatorsOfQ58)

if __name__ == '__main__':
    answers()