from sympy import mod_inverse
import time

def calc():
    p = 10106404377238244429826597333701722135807526565404559030730896339579442857374388664504194768519009799965064145557030402164596983123568189834021494235031749
    q = 13163502274590772696691357017188157383494073914454743555560229941893711785933411409679348168803213122008986323048364979277888128708485862429032314868646957
    n = p*q
    c = 86558429746256786220797160070602630299194622171442102432718868178774008203963283371082296312613592328933331443800737112868177768290770644915753506516969943009267919574620060086036513229518287908509845029476546407334692827450859273444583008387805272482776780230890488254799112954960574416568539455497347050126
    e = 67

    #Compute m = c^d  mod n  (where d = e^-1 mod phi(n)).

    start_of_a = time.time()

    d = (mod_inverse(e,int((p - 1) * (q - 1))))
    print("I found d! It is: ", d)
    m = pow(c, d, n)
    print("m is", m)

    end_of_a = time.time()

    qInverse = mod_inverse(q, p)
    pInverse = mod_inverse(p, q)

    print("p (mod q):", pInverse)
    print("q (mod p):", qInverse)

    start_of_b = time.time()

    dq = mod_inverse(e, q - 1)  # inverse of e modulo q-1
    dp = mod_inverse(e, p - 1)  # inverse of e modulo p-1
    print("d (mod p-1):", dp)
    print("d (mod q-1):", dq)

    cq = c % q  # c mod q
    cp = c % p  # c mod p
    print("c (mod p):", cp)
    print("c (mod q):", cq)

    mq = pow(cq, dq, q)  # c^d mod q
    mp = pow(cp, dp, p)  # c^d mod p

    print("c^d (mod p):", mp)

    print("c^d (mod q):", mq)

    """
    Now according to Gauss' algorithm,
    m = c^d mod(pxq) = cp*(q)*(q' mod p) + cq*(p)*(p' mod q)
    """


    n= p*q

    m = (mp*q*qInverse) % n + (mq*p*pInverse) % n

    print("m is:", m)

    end_of_b = time.time()

    print("Excution times:", "for a)", end_of_a-start_of_a, "and for b)", end_of_b-start_of_b)
    print("WE CLEARLY SEE THAT CRT IS ALMOST 3 TIMES FASTER THAN THE FIRST CALCULATION METHOD.")


if __name__ == '__main__':
    calc()