def init_register(n):
        register = []
        for i in range(0, n):
            register.append(0)
        return register


def LFSR(register, FeedbackBit):
    new_register = init_register(len(register))
    for i in range(0, len(register) - 1):
        new_register[i] = register[i + 1]
    new_register[i + 1] = FeedbackBit
    return new_register


def test_LFSR0():

    register = [1,0,0,0,1]
    register2 = [1,1,0,0]
    register_initial = register
    register_initial2 = register2
    print(register)
    count = 0

    for i in range(0, 31):
        register = LFSR(register, (register[0] ^ (register[4])))
        count = count + 1
        print(register)
        if(register_initial == register):
            print("Total count is", count)

    count2 = 0
    print("")
    print(register2)
    for i in range(0, 15):
        register2 = LFSR(register2, (register2[0] ^ (register2[1])))
        count2 = count2 + 1
        print(register2)
        if(register_initial2 == register2):
            print("Total count is", count2)


if __name__ == '__main__':
    test_LFSR0()